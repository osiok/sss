<?php
declare(strict_types=1);
namespace ZSG\Auth\Database;
use ZSG\Auth\Support\Logger;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Migrator {
    public function needs_migration(): bool {
        $cur = (string) get_option( 'zsg_auth_schema_version', '0' );
        return version_compare( $cur, ZSG_AUTH_SCHEMA_VERSION, '<' );
    }

    public function run(): void {
        $cur = (string) get_option( 'zsg_auth_schema_version', '0' );
        Logger::instance()->info( 'Migration started', [ 'from' => $cur, 'to' => ZSG_AUTH_SCHEMA_VERSION ] );
        Installer::install();
        Logger::instance()->info( 'Migration completed', [ 'version' => ZSG_AUTH_SCHEMA_VERSION ] );
    }
}
