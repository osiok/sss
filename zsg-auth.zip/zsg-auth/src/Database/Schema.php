<?php
declare(strict_types=1);
namespace ZSG\Auth\Database;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Schema {
    public static function tables(): array {
        global $wpdb;
        $p = $wpdb->prefix . 'zsg_auth_';
        $c = $wpdb->get_charset_collate();

        return [
            'otp' => "CREATE TABLE {$p}otp (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                identifier_hash CHAR(64) NOT NULL,
                code_hash CHAR(255) NOT NULL,
                purpose VARCHAR(32) NOT NULL DEFAULT 'login',
                attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
                max_attempts SMALLINT UNSIGNED NOT NULL DEFAULT 5,
                expires_at DATETIME NOT NULL,
                used_at DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY identifier_purpose (identifier_hash, purpose),
                KEY expires_at (expires_at)
            ) {$c};",

            'limits' => "CREATE TABLE {$p}limits (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                limit_key CHAR(64) NOT NULL,
                limit_type VARCHAR(32) NOT NULL,
                count INT UNSIGNED NOT NULL DEFAULT 0,
                window_start DATETIME NOT NULL,
                locked_until DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY limit_unique (limit_key, limit_type, window_start),
                KEY locked_until (locked_until)
            ) {$c};",

            'sessions' => "CREATE TABLE {$p}sessions (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id BIGINT UNSIGNED NOT NULL,
                token_hash CHAR(64) NOT NULL,
                device_info VARCHAR(255) NULL,
                ip_hash CHAR(64) NULL,
                last_activity DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                expires_at DATETIME NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY token_hash (token_hash),
                KEY user_id (user_id),
                KEY expires_at (expires_at)
            ) {$c};",

            'devices' => "CREATE TABLE {$p}devices (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id BIGINT UNSIGNED NOT NULL,
                device_fingerprint CHAR(64) NOT NULL,
                device_name VARCHAR(255) NULL,
                trusted TINYINT(1) NOT NULL DEFAULT 0,
                last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY user_device (user_id, device_fingerprint),
                KEY last_seen (last_seen)
            ) {$c};",

            'passkeys' => "CREATE TABLE {$p}passkeys (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id BIGINT UNSIGNED NOT NULL,
                credential_id VARCHAR(255) NOT NULL,
                public_key TEXT NOT NULL,
                sign_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
                device_name VARCHAR(255) NULL,
                aaguid CHAR(36) NULL,
                last_used_at DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY credential_id (credential_id),
                KEY user_id (user_id)
            ) {$c};",

            'logs' => "CREATE TABLE {$p}logs (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                event_type VARCHAR(64) NOT NULL,
                user_id BIGINT UNSIGNED NULL,
                ip_hash CHAR(64) NULL,
                severity VARCHAR(16) NOT NULL DEFAULT 'info',
                metadata LONGTEXT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY event_type (event_type),
                KEY user_id (user_id),
                KEY created_at (created_at)
            ) {$c};",

            'challenges' => "CREATE TABLE {$p}challenges (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                challenge_hash CHAR(64) NOT NULL,
                purpose VARCHAR(32) NOT NULL,
                payload LONGTEXT NULL,
                expires_at DATETIME NOT NULL,
                used_at DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY challenge_hash (challenge_hash),
                KEY expires_at (expires_at)
            ) {$c};",
        ];
    }
}
