<?php
declare(strict_types=1);
namespace ZSG\Auth\Database;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Installer {
    public static function install(): void {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ( Schema::tables() as $sql ) { dbDelta( $sql ); }
        update_option( 'zsg_auth_schema_version', ZSG_AUTH_SCHEMA_VERSION, false );
        self::set_defaults();
    }

    private static function set_defaults(): void {
        $defaults = [
            'zsg_auth_otp_length'              => 6,
            'zsg_auth_otp_expiry'              => 120,
            'zsg_auth_otp_max_attempts'        => 5,
            'zsg_auth_resend_cooldown'         => 60,
            'zsg_auth_rate_limit_ip_window'    => 600,
            'zsg_auth_rate_limit_ip_max'       => 10,
            'zsg_auth_rate_limit_phone_hourly' => 3,
            'zsg_auth_rate_limit_phone_daily'  => 5,
            'zsg_auth_default_role'            => 'customer',
            'zsg_auth_login_methods'           => [ 'otp' ],
            'zsg_auth_provider_primary'        => '',
            'zsg_auth_captcha_after_failures'  => 3,
            'zsg_auth_help_hint_delay'         => 15,
        ];
        foreach ( $defaults as $k => $v ) {
            if ( false === get_option( $k, false ) ) { add_option( $k, $v, '', false ); }
        }
    }
}
