<?php
declare(strict_types=1);
namespace ZSG\Auth\Security;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Logout {
    public static function register(): void {
        add_action( 'init', [ __CLASS__, 'maybe_handle' ], 1 );
    }

    public static function maybe_handle(): void {
        if ( empty( $_POST['zsg_logout'] ) ) { return; }

        $nonce = isset( $_POST['_zsg_nonce'] ) ? (string) $_POST['_zsg_nonce'] : '';
        if ( ! wp_verify_nonce( $nonce, 'zsg_logout' ) ) {
            wp_die( 'درخواست نامعتبر', 'خطا', [ 'response' => 403 ] );
        }

        // Revoke our custom session
        if ( isset( $_COOKIE['zsg_session'] ) ) {
            try {
                $sm = new SessionManager();
                $sm->revoke( sanitize_text_field( wp_unslash( $_COOKIE['zsg_session'] ) ) );
            } catch ( \Throwable $e ) {
                // ignore
            }
            setcookie( 'zsg_session', '', [
                'expires'  => time() - 3600,
                'path'     => COOKIEPATH ?: '/',
                'domain'   => COOKIE_DOMAIN ?: '',
                'secure'   => is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax',
            ] );
        }

        // WordPress logout
        wp_logout();

        // Redirect to WooCommerce My Account (like wc_logout_url target)
        $redirect = home_url( '/' );
        if ( function_exists( 'wc_get_page_permalink' ) ) {
            $wc_my = wc_get_page_permalink( 'myaccount' );
            if ( $wc_my ) { $redirect = $wc_my; }
        } elseif ( function_exists( 'wc_get_account_endpoint_url' ) ) {
            $endpoint = wc_get_account_endpoint_url( 'customer-logout' );
            if ( $endpoint ) { $redirect = $endpoint; }
        }
        wp_safe_redirect( $redirect );
        exit;
    }

    public static function button_html( string $label = 'خروج از حساب' ): string {
        $action = esc_url( home_url( '/' ) );
        $nonce  = wp_create_nonce( 'zsg_logout' );
        return '<form method="post" action="' . $action . '" style="margin:0;padding:0;">'
            . '<input type="hidden" name="zsg_logout" value="1">'
            . '<input type="hidden" name="_zsg_nonce" value="' . esc_attr( $nonce ) . '">'
            . '<button type="submit" class="zsg-btn zsg-btn-destructive" style="width:100%;">'
            . esc_html( $label )
            . '</button></form>';
    }
}
