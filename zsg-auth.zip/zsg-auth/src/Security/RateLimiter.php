<?php
declare(strict_types=1);
namespace ZSG\Auth\Security;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class RateLimiter {
    private static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 'zsg_auth_limits';
    }

    /**
     * @return array{allowed:bool, remaining:int, retry_after:int, total:int}
     */
    public static function attempt( string $key, string $type, int $max, int $window_seconds ): array {
        global $wpdb;
        $table = self::table();

        // Insert new row (or bump existing same-second row)
        $wpdb->query( $wpdb->prepare(
            "INSERT INTO {$table} (limit_key, limit_type, count, window_start, created_at)
             VALUES (%s, %s, 1, UTC_TIMESTAMP(), UTC_TIMESTAMP())
             ON DUPLICATE KEY UPDATE count = count + 1",
            $key, $type
        ) );

        // Sum within sliding window
        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(count), 0) FROM {$table}
             WHERE limit_key = %s AND limit_type = %s
               AND window_start > DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d SECOND)",
            $key, $type, $window_seconds
        ) );

        $allowed   = $total <= $max;
        $remaining = max( 0, $max - $total );

        $retry_after = 0;
        if ( ! $allowed ) {
            $earliest = $wpdb->get_var( $wpdb->prepare(
                "SELECT MIN(window_start) FROM {$table}
                 WHERE limit_key = %s AND limit_type = %s
                   AND window_start > DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d SECOND)",
                $key, $type, $window_seconds
            ) );
            if ( $earliest ) {
                $reset_ts    = strtotime( $earliest . ' UTC' ) + $window_seconds;
                $retry_after = max( 1, $reset_ts - time() );
            } else {
                $retry_after = $window_seconds;
            }
        }

        return [ 'allowed' => $allowed, 'remaining' => $remaining, 'retry_after' => $retry_after, 'total' => $total ];
    }

    public static function cleanup( int $older_than_seconds = 86400 ): void {
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM " . self::table() . " WHERE window_start < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d SECOND)",
            $older_than_seconds
        ) );
    }
}
