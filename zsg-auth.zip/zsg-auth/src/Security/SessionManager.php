<?php
declare(strict_types=1);
namespace ZSG\Auth\Security;
use ZSG\Auth\Support\Helpers;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class SessionManager {
    private string $table;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'zsg_auth_sessions';
    }

    public function create( int $user_id, string $device_info = '' ): string {
        global $wpdb;
        $token = bin2hex( random_bytes( 32 ) );
        $token_hash = hash_hmac( 'sha256', $token, wp_salt( 'auth' ) );
        $lifetime = (int) get_option( 'zsg_auth_session_lifetime', 30 * 86400 );
        $expires  = gmdate( 'Y-m-d H:i:s', time() + $lifetime );

        // Enforce max concurrent devices
        $max = (int) get_option( 'zsg_auth_max_devices', 5 );
        if ( $max > 0 ) {
            $count = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table} WHERE user_id = %d AND expires_at > UTC_TIMESTAMP()",
                $user_id
            ) );
            if ( $count >= $max ) {
                $excess = $count - $max + 1;
                $wpdb->query( $wpdb->prepare(
                    "DELETE FROM {$this->table} WHERE user_id = %d ORDER BY last_activity ASC LIMIT %d",
                    $user_id, $excess
                ) );
            }
        }

        $wpdb->insert( $this->table, [
            'user_id'       => $user_id,
            'token_hash'    => $token_hash,
            'device_info'   => mb_substr( $device_info, 0, 250 ),
            'ip_hash'       => Helpers::hash_identifier( $this->client_ip() ),
            'last_activity' => gmdate( 'Y-m-d H:i:s' ),
            'expires_at'    => $expires,
            'created_at'    => gmdate( 'Y-m-d H:i:s' ),
        ], [ '%d', '%s', '%s', '%s', '%s', '%s', '%s' ] );

        return $token;
    }

    public function validate( string $token ): ?int {
        global $wpdb;
        $token_hash = hash_hmac( 'sha256', $token, wp_salt( 'auth' ) );
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT user_id FROM {$this->table} WHERE token_hash = %s AND expires_at > UTC_TIMESTAMP()",
            $token_hash
        ) );
        if ( ! $row ) { return null; }
        $wpdb->update( $this->table, [ 'last_activity' => gmdate( 'Y-m-d H:i:s' ) ], [ 'token_hash' => $token_hash ], [ '%s' ], [ '%s' ] );
        return (int) $row->user_id;
    }

    public function revoke( string $token ): void {
        global $wpdb;
        $token_hash = hash_hmac( 'sha256', $token, wp_salt( 'auth' ) );
        $wpdb->delete( $this->table, [ 'token_hash' => $token_hash ], [ '%s' ] );
    }

    public function revoke_all( int $user_id ): void {
        global $wpdb;
        $wpdb->delete( $this->table, [ 'user_id' => $user_id ], [ '%d' ] );
    }

    public function list_for_user( int $user_id ): array {
        global $wpdb;
        return (array) $wpdb->get_results( $wpdb->prepare(
            "SELECT id, device_info, last_activity, expires_at, created_at FROM {$this->table}
             WHERE user_id = %d AND expires_at > UTC_TIMESTAMP() ORDER BY last_activity DESC",
            $user_id
        ) );
    }

    public function cleanup(): void {
        global $wpdb;
        $wpdb->query( "DELETE FROM {$this->table} WHERE expires_at < UTC_TIMESTAMP()" );
    }

    private function client_ip(): string {
        $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
        return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
    }
}
