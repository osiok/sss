<?php
declare(strict_types=1);
namespace ZSG\Auth\Access;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Metabox {
    public static function register(): void {
        add_action( 'add_meta_boxes', [ __CLASS__, 'add' ] );
        add_action( 'save_post',      [ __CLASS__, 'save' ], 10, 2 );
    }

    public static function add(): void {
        foreach ( [ 'page', 'post' ] as $type ) {
            add_meta_box(
                'zsg_lock_mode',
                'ZSG Auth — قفل دسترسی',
                [ __CLASS__, 'render' ],
                $type,
                'side',
                'default'
            );
        }
    }

    public static function render( \WP_Post $post ): void {
        wp_nonce_field( 'zsg_lock_meta', 'zsg_lock_nonce' );
        $current = (string) get_post_meta( $post->ID, PageLock::META_KEY, true );
        if ( ! in_array( $current, PageLock::MODES, true ) ) { $current = 'none'; }
        ?>
        <p style="margin:0 0 6px;"><strong>کاربران وارد‌نشده:</strong></p>
        <label style="display:block;margin:6px 0;">
          <input type="radio" name="zsg_lock_mode" value="none" <?php checked( $current, 'none' ); ?>>
          باز (بدون قفل)
        </label>
        <label style="display:block;margin:6px 0;">
          <input type="radio" name="zsg_lock_mode" value="popup" <?php checked( $current, 'popup' ); ?>>
          پاپ‌آپ ورود روی همین صفحه
        </label>
        <label style="display:block;margin:6px 0;">
          <input type="radio" name="zsg_lock_mode" value="redirect" <?php checked( $current, 'redirect' ); ?>>
          ریدایرکت به صفحه‌ی ورود
        </label>
        <p style="color:#666;font-size:11px;margin:8px 0 0;">
          کاربران وارد‌شده هیچ تغییری نمی‌بینند. بعد از ورود، به همین صفحه برمی‌گردند.
        </p>
        <?php
    }

    public static function save( int $post_id, \WP_Post $post ): void {
        if ( ! isset( $_POST['zsg_lock_nonce'] ) ) { return; }
        $nonce = (string) $_POST['zsg_lock_nonce'];
        if ( ! wp_verify_nonce( $nonce, 'zsg_lock_meta' ) ) { return; }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
        if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }

        $mode = isset( $_POST['zsg_lock_mode'] ) ? (string) $_POST['zsg_lock_mode'] : 'none';
        if ( ! in_array( $mode, PageLock::MODES, true ) ) { $mode = 'none'; }

        if ( 'none' === $mode ) {
            delete_post_meta( $post_id, PageLock::META_KEY );
        } else {
            update_post_meta( $post_id, PageLock::META_KEY, $mode );
        }
    }
}
