<?php
declare(strict_types=1);
namespace ZSG\Auth\Access;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class PageLock {
    const META_KEY = '_zsg_lock_mode';
    const MODES    = [ 'none', 'popup', 'redirect' ];

    public static function register(): void {
        add_action( 'template_redirect', [ __CLASS__, 'maybe_lock' ], 1 );
        add_action( 'wp_footer',          [ __CLASS__, 'render_overlay' ], 99 );
    }

    public static function is_locked_page(): bool {
        if ( is_admin() || is_user_logged_in() ) { return false; }
        if ( self::is_login_page() ) { return false; }
        if ( self::is_login_url_slug() ) { return false; }
        if ( ! is_singular() ) { return false; }

        $id   = (int) get_queried_object_id();
        $mode = (string) get_post_meta( $id, self::META_KEY, true );
        return in_array( $mode, [ 'popup', 'redirect' ], true );
    }

    public static function current_mode(): string {
        if ( ! is_singular() ) { return 'none'; }
        $id   = (int) get_queried_object_id();
        $mode = (string) get_post_meta( $id, self::META_KEY, true );
        return in_array( $mode, self::MODES, true ) ? $mode : 'none';
    }

    public static function maybe_lock(): void {
        if ( is_user_logged_in() ) { return; }
        if ( ! self::is_locked_page() ) { return; }

        $mode = self::current_mode();

        if ( 'redirect' === $mode ) {
            $login_url = self::login_page_url();
            if ( ! $login_url ) { return; }
            $back     = self::current_url();
            $redirect = add_query_arg( 'redirect_to', rawurlencode( $back ), $login_url );
            wp_safe_redirect( $redirect );
            exit;
        }

        if ( 'popup' === $mode ) {
            add_filter( 'body_class', static function ( $classes ) {
                $classes[] = 'zsg-page-locked';
                return $classes;
            } );
        }
    }

    public static function render_overlay(): void {
        if ( is_user_logged_in() ) { return; }
        if ( ! self::is_locked_page() ) { return; }
        if ( 'popup' !== self::current_mode() ) { return; }

        $args = [ 'force_open' => true ];
        $view = ZSG_AUTH_PATH . 'src/Frontend/Views/modal.php';
        if ( is_readable( $view ) ) {
            include $view;
        }
    }

    public static function login_page_url(): string {
        $id = (int) get_option( 'zsg_auth_login_page_id', 0 );
        if ( $id > 0 && 'publish' === get_post_status( $id ) ) {
            $url = get_permalink( $id );
            if ( $url ) { return (string) $url; }
        }
        return (string) home_url( '/login/' );
    }

    public static function current_url(): string {
        $host   = isset( $_SERVER['HTTP_HOST'] ) ? (string) $_SERVER['HTTP_HOST'] : '';
        $uri    = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '/';
        $scheme = is_ssl() ? 'https' : 'http';
        return $scheme . '://' . $host . $uri;
    }

    private static function is_login_page(): bool {
        $id = (int) get_option( 'zsg_auth_login_page_id', 0 );
        if ( $id > 0 && is_page( $id ) ) { return true; }
        return false;
    }

    private static function is_login_url_slug(): bool {
        if ( ! is_singular() ) { return false; }
        $id = (int) get_option( 'zsg_auth_login_page_id', 0 );
        return $id > 0 && get_queried_object_id() === $id;
    }
}
