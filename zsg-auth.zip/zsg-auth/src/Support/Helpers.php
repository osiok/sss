<?php
declare(strict_types=1);
namespace ZSG\Auth\Support;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Helpers {

    public static function to_english_digits( string $input ): string {
        return strtr( $input, [
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
        ] );
    }

    public static function normalize_phone( string $raw ): string {
        $digits = self::to_english_digits( $raw );
        $digits = preg_replace( '/\D+/', '', $digits );
        if ( ! is_string( $digits ) || '' === $digits ) { return ''; }

        if ( str_starts_with( $digits, '0098' ) ) {
            $digits = substr( $digits, 4 );
        } elseif ( str_starts_with( $digits, '98' ) && 12 === strlen( $digits ) ) {
            $digits = substr( $digits, 2 );
        } elseif ( str_starts_with( $digits, '0' ) ) {
            $digits = substr( $digits, 1 );
        }

        if ( 10 !== strlen( $digits ) || '9' !== $digits[0] ) { return ''; }
        return '+98' . $digits;
    }

    public static function mask_phone( string $phone ): string {
        $digits = preg_replace( '/\D+/', '', $phone );
        if ( ! is_string( $digits ) ) { return '***'; }

        if ( strlen( $digits ) === 12 && str_starts_with( $digits, '98' ) ) {
            $local = substr( $digits, 2 );
            return '0' . substr( $local, 0, 3 ) . '***' . substr( $local, -4 );
        }
        if ( strlen( $digits ) < 10 ) { return '***'; }
        return '0' . substr( $digits, 0, 3 ) . '***' . substr( $digits, -4 );
    }

    public static function hash_identifier( string $identifier ): string {
        return hash_hmac( 'sha256', $identifier, wp_salt( 'auth' ) );
    }
}
