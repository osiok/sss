<?php
declare(strict_types=1);
namespace ZSG\Auth\Support;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Logger {
    private static ?self $instance = null;
    private const MASKED = [ 'password','pass','otp','code','token','secret','api_key','authorization','cookie','totp_secret','private_key' 
];

    public static function instance(): self { return self::$instance ??= new self(); }
    private function __construct() {}

    public function debug( string $m, array $c = [] ): void {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) { $this->log( 'debug', $m, $c ); }
    }
    public function info( string $m, array $c = [] ): void    { $this->log( 'info', $m, $c ); }
    public function warning( string $m, array $c = [] ): void { $this->log( 'warning', $m, $c ); }
    public function error( string $m, array $c = [] ): void   { $this->log( 'error', $m, $c ); }

    private function log( string $level, string $msg, array $ctx ): void {
        $safe = $this->mask( $ctx );
        $line = sprintf( '[ZSG Auth][%s] %s %s', strtoupper( $level ), $msg, $safe ? wp_json_encode( $safe ) : '' );
        error_log( $line ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
    }

    private function mask( array $ctx ): array {
        foreach ( $ctx as $k => $v ) {
            $lower = strtolower( (string) $k );
            foreach ( self::MASKED as $m ) {
                if ( str_contains( $lower, $m ) ) { $ctx[ $k ] = '[REDACTED]'; continue 2; }
            }
            if ( is_array( $v ) ) { $ctx[ $k ] = $this->mask( $v ); }
        }
        return $ctx;
    }
}
