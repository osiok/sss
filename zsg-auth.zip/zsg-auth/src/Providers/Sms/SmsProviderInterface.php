<?php
declare(strict_types=1);
namespace ZSG\Auth\Providers\Sms;
if ( ! defined( 'ABSPATH' ) ) { exit; }

interface SmsProviderInterface {
    /**
     * @return array{success:bool, message:string, raw:mixed}
     */
    public function send( string $phone, string $code, string $purpose ): array;
    public function name(): string;
}
