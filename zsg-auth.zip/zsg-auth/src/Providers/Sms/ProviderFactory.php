<?php
declare(strict_types=1);
namespace ZSG\Auth\Providers\Sms;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class ProviderFactory {
    public static function make(): SmsProviderInterface {
        $primary = (string) get_option( 'zsg_auth_provider_primary', 'mock' );
        switch ( $primary ) {
            case 'ippanel':
                if ( class_exists( __NAMESPACE__ . '\\IPPanelProvider' ) ) {
                    return new IPPanelProvider();
                }
                return new MockProvider();
            case 'mock':
            default:
                return new MockProvider();
        }
    }
}
