<?php
declare(strict_types=1);
namespace ZSG\Auth\Providers\Sms;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class MockProvider implements SmsProviderInterface {
    public function name(): string { return 'mock'; }

    public function send( string $phone, string $code, string $purpose ): array {
        $uploads = wp_upload_dir();
        if ( ! empty( $uploads['error'] ) ) {
            return [ 'success' => false, 'message' => 'Uploads dir error: ' . $uploads['error'], 'raw' => null ];
        }
        $log_file = trailingslashit( $uploads['basedir'] ) . 'zsg-auth-mock.log';
        $line = gmdate( 'c' ) . ' | ' . $purpose . ' | ' . $phone . ' | ' . $code . "\n";
        $ok   = @file_put_contents( $log_file, $line, FILE_APPEND | LOCK_EX );
        if ( false === $ok ) {
            return [ 'success' => false, 'message' => 'Cannot write mock log file', 'raw' => null ];
        }
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions
        error_log( '[ZSG Auth][Mock] OTP for ' . $phone . ': ' . $code );
        return [ 'success' => true, 'message' => 'Mock sent', 'raw' => $line ];
    }
}
