<?php
declare(strict_types=1);
namespace ZSG\Auth\Otp;
use ZSG\Auth\Providers\Sms\ProviderFactory;
use ZSG\Auth\Support\Helpers;
use ZSG\Auth\Support\Logger;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class OtpEngine {

    public static function create( string $phone, string $purpose = 'login' ): array {
        $normalized = Helpers::normalize_phone( $phone );
        if ( ! $normalized ) {
            return [ 'success' => false, 'error' => 'invalid_phone', 'message' => 'شماره نامعتبر است' ];
        }

        $length  = (int) get_option( 'zsg_auth_otp_length', 6 );
        $ttl     = (int) get_option( 'zsg_auth_otp_expiry', 120 );
        $max_att = (int) get_option( 'zsg_auth_otp_max_attempts', 5 );

        try {
            $code = OtpGenerator::generate( $length );
        } catch ( \Throwable $e ) {
            Logger::instance()->error( 'OTP generation failed', [ 'error' => $e->getMessage() ] );
            return [ 'success' => false, 'error' => 'server_error', 'message' => 'خطای داخلی سرور' ];
        }

        $repo = new OtpRepository();
        $id   = $repo->create( $normalized, $code, $purpose, $ttl, $max_att );
        if ( ! $id ) {
            return [ 'success' => false, 'error' => 'server_error', 'message' => 'خطا در ذخیره‌سازی' ];
        }

        $provider = ProviderFactory::make();
        $result   = $provider->send( $normalized, $code, $purpose );

        if ( empty( $result['success'] ) ) {
            Logger::instance()->error( 'OTP send failed', [
                'provider' => $provider->name(),
                'message'  => $result['message'] ?? 'unknown',
            ] );
            // Invalidate the OTP so it can't be used
            $repo->increment_attempts( $normalized, $purpose );
            return [ 'success' => false, 'error' => 'provider_error', 'message' => 'ارسال کد با خطا مواجه شد' ];
        }

        Logger::instance()->info( 'OTP sent', [
            'phone'    => Helpers::mask_phone( $normalized ),
            'provider' => $provider->name(),
        ] );

        return [
            'success'    => true,
            'expires_in' => $ttl,
            'masked_phone' => Helpers::mask_phone( $normalized ),
        ];
    }

    public static function verify( string $phone, string $code, string $purpose = 'login' ): array {
        $normalized = Helpers::normalize_phone( $phone );
        if ( ! $normalized ) {
            return [ 'success' => false, 'error' => 'invalid_phone', 'message' => 'شماره نامعتبر است', 'http_status' => 400 ];
        }

        $expected_len = (int) get_option( 'zsg_auth_otp_length', 6 );
        $clean_code   = preg_replace( '/\D+/', '', Helpers::to_english_digits( $code ) );
        if ( ! is_string( $clean_code ) || strlen( $clean_code ) !== $expected_len ) {
            return [ 'success' => false, 'error' => 'invalid_code', 'message' => 'کد وارد شده صحیح نیست', 'http_status' => 400 ];
        }

        $repo = new OtpRepository();

        if ( $repo->consume_atomic( $normalized, $clean_code, $purpose ) ) {
            Logger::instance()->info( 'OTP verified', [ 'phone' => Helpers::mask_phone( $normalized ) ] );
            return [ 'success' => true, 'verified' => true, 'phone' => $normalized ];
        }

        // Not consumed — increment attempts to detect brute force
        $attempts = $repo->increment_attempts( $normalized, $purpose );

        Logger::instance()->info( 'OTP verify failed', [
            'phone'    => Helpers::mask_phone( $normalized ),
            'attempts' => $attempts,
        ] );

        return [ 'success' => false, 'error' => 'invalid_code', 'message' => 'کد وارد شده صحیح نیست یا منقضی شده است', 'http_status' => 401 ];
    }
}
