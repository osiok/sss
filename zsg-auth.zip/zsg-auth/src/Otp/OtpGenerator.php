<?php
declare(strict_types=1);
namespace ZSG\Auth\Otp;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class OtpGenerator {
    public static function generate( int $length = 6 ): string {
        if ( $length < 4 || $length > 10 ) {
            throw new \InvalidArgumentException( 'OTP length must be between 4 and 10.' );
        }
        $code = '';
        for ( $i = 0; $i < $length; $i++ ) {
            $code .= (string) random_int( 0, 9 );
        }
        return $code;
    }

    public static function token( int $bytes = 32 ): string {
        return bin2hex( random_bytes( $bytes ) );
    }
}
