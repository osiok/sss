<?php
declare(strict_types=1);
namespace ZSG\Auth\Otp;
use ZSG\Auth\Support\Helpers;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class OtpRepository {
    private \wpdb $db;
    private string $table;

    public function __construct() {
        global $wpdb;
        $this->db = $wpdb;
        $this->table = $wpdb->prefix . 'zsg_auth_otp';
    }

    public function create( string $identifier, string $code, string $purpose, int $ttl, int $max_attempts ): int {
        $id_hash   = Helpers::hash_identifier( $identifier );
        $code_hash = hash_hmac( 'sha256', $code, wp_salt( 'auth' ) );
        $now       = gmdate( 'Y-m-d H:i:s' );
        $expires   = gmdate( 'Y-m-d H:i:s', time() + $ttl );

        // Invalidate any active OTP for same identifier+purpose
        $this->db->query( $this->db->prepare(
            "UPDATE {$this->table} SET used_at = UTC_TIMESTAMP() WHERE identifier_hash = %s AND purpose = %s AND used_at IS NULL",
            $id_hash, $purpose
        ) );

        $this->db->insert( $this->table, [
            'identifier_hash' => $id_hash,
            'code_hash'       => $code_hash,
            'purpose'         => $purpose,
            'attempts'        => 0,
            'max_attempts'    => $max_attempts,
            'expires_at'      => $expires,
            'created_at'      => $now,
        ], [ '%s', '%s', '%s', '%d', '%d', '%s', '%s' ] );

        return (int) $this->db->insert_id;
    }

    /**
     * Atomically marks the OTP as used. Returns true only if this request won the race.
     */
    public function consume_atomic( string $identifier, string $code, string $purpose ): bool {
        $id_hash   = Helpers::hash_identifier( $identifier );
        $code_hash = hash_hmac( 'sha256', $code, wp_salt( 'auth' ) );

        $sql = $this->db->prepare(
            "UPDATE {$this->table}
             SET used_at = UTC_TIMESTAMP()
             WHERE identifier_hash = %s
               AND code_hash = %s
               AND purpose = %s
               AND used_at IS NULL
               AND expires_at > UTC_TIMESTAMP()",
            $id_hash, $code_hash, $purpose
        );
        $result = $this->db->query( $sql );
        return $result !== false && $this->db->rows_affected === 1;
    }

    public function increment_attempts( string $identifier, string $purpose ): int {
        $id_hash = Helpers::hash_identifier( $identifier );
        $row = $this->db->get_row( $this->db->prepare(
            "SELECT id, attempts, max_attempts FROM {$this->table}
             WHERE identifier_hash = %s AND purpose = %s AND used_at IS NULL AND expires_at > UTC_TIMESTAMP()
             ORDER BY id DESC LIMIT 1",
            $id_hash, $purpose
        ) );

        if ( ! $row ) { return -1; }

        $attempts = (int) $row->attempts + 1;
        $invalid  = $attempts >= (int) $row->max_attempts;

        $this->db->update(
            $this->table,
            [ 'attempts' => $attempts, 'used_at' => $invalid ? gmdate( 'Y-m-d H:i:s' ) : null ],
            [ 'id' => (int) $row->id ],
            [ '%d', '%s' ],
            [ '%d' ]
        );
        return $attempts;
    }

    public function has_active( string $identifier, string $purpose ): bool {
        $id_hash = Helpers::hash_identifier( $identifier );
        $count = (int) $this->db->get_var( $this->db->prepare(
            "SELECT COUNT(*) FROM {$this->table}
             WHERE identifier_hash = %s AND purpose = %s AND used_at IS NULL AND expires_at > UTC_TIMESTAMP()",
            $id_hash, $purpose
        ) );
        return $count > 0;
    }

    public function cleanup_expired( int $older_than_seconds = 3600 ): void {
        $this->db->query( $this->db->prepare(
            "DELETE FROM {$this->table} WHERE expires_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d SECOND)",
            $older_than_seconds
        ) );
    }
}
