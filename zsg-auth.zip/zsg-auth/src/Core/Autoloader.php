<?php
declare(strict_types=1);
namespace ZSG\Auth\Core;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Autoloader {
    private const PREFIX = 'ZSG\\Auth\\';
    public static function register(): void {
        spl_autoload_register( [ __CLASS__, 'load' ] );
    }
    public static function load( string $class ): void {
        if ( ! str_starts_with( $class, self::PREFIX ) ) { return; }
        $rel  = substr( $class, strlen( self::PREFIX ) );
        $file = ZSG_AUTH_PATH . 'src/' . str_replace( '\\', '/', $rel ) . '.php';
        if ( is_readable( $file ) ) { require_once $file; }
    }
}
