<?php
declare(strict_types=1);
namespace ZSG\Auth\Core;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class AdminMenu {
    private static ?self $instance = null;
    public static function instance(): self { return self::$instance ??= new self(); }
    private function __construct() {}

    public function register(): void {
        add_action( 'admin_menu', [ $this, 'add_menu' ] );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
    }

    public function add_menu(): void {
        add_menu_page(
            __( 'ZSG Auth', 'zsg-auth' ),
            __( 'ZSG Auth', 'zsg-auth' ),
            'manage_options',
            'zsg-auth',
            [ $this, 'render_dashboard' ],
            'dashicons-shield-alt',
            30
        );

        add_submenu_page(
            'zsg-auth',
            __( 'داشبورد', 'zsg-auth' ),
            __( 'داشبورد', 'zsg-auth' ),
            'manage_options',
            'zsg-auth',
            [ $this, 'render_dashboard' ]
        );

        add_submenu_page(
            'zsg-auth',
            __( 'تنظیمات امنیتی', 'zsg-auth' ),
            __( 'تنظیمات امنیتی', 'zsg-auth' ),
            'manage_options',
            'zsg-auth-security',
            [ $this, 'render_security' ]
        );
    }

    public function register_settings(): void {
        register_setting( 'zsg_auth_security', 'zsg_auth_session_lifetime', [
            'type'              => 'integer',
            'sanitize_callback' => 'absint',
            'default'           => 30 * 86400,
        ] );
        register_setting( 'zsg_auth_security', 'zsg_auth_max_devices', [
            'type'              => 'integer',
            'sanitize_callback' => 'absint',
            'default'           => 5,
        ] );
        register_setting( 'zsg_auth_security', 'zsg_auth_otp_length', [ 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 6 ] );
        register_setting( 'zsg_auth_security', 'zsg_auth_otp_clipboard_enabled', [ 'type' => 'boolean', 'sanitize_callback' => function( $v ){ return $v ? 1 : 0; }, 'default' => 1 ] );
        register_setting( 'zsg_auth_security', 'zsg_auth_otp_clipboard_pattern', [ 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field', 'default' => 'Code: {code}' ] );
        register_setting( 'zsg_auth_security', 'zsg_auth_login_page_id', [
            'type'              => 'integer',
            'sanitize_callback' => 'absint',
            'default'           => 0,
        ] );
    }

    public function render_dashboard(): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'دسترسی غیرمجاز' ); }
        $schema = get_option( 'zsg_auth_schema_version', '?' );
        ?>
        <div class="wrap" dir="rtl">
            <h1>ZSG Auth — داشبورد</h1>
            <p>نسخه افزونه: <strong><?php echo esc_html( ZSG_AUTH_VERSION ); ?></strong></p>
            <p>نسخه Schema: <strong><?php echo esc_html( (string) $schema ); ?></strong></p>
            <p style="margin-top:20px;">
              <a href="<?php echo esc_url( admin_url( 'admin.php?page=zsg-auth-security' ) ); ?>" class="button button-primary">
                رفتن به تنظیمات امنیتی →
              </a>
            </p>
            <hr style="margin:24px 0;">
            <h2>وضعیت سریع</h2>
            <ul style="list-style:none;padding:0;">
                <li>Session Lifetime: <strong><?php echo esc_html( (string) round( (int) get_option( 'zsg_auth_session_lifetime', 30 * 86400 ) / 86400 ) ); ?> روز</strong></li>
                <li>Max Devices: <strong><?php echo esc_html( (string) get_option( 'zsg_auth_max_devices', 5 ) ); ?></strong></li>
                <li>Login Page: <strong><?php echo esc_html( get_the_title( (int) get_option( 'zsg_auth_login_page_id', 0 ) ) ?: '—' ); ?></strong></li>
            </ul>
        </div>
        <?php
    }

    public function render_security(): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'دسترسی غیرمجاز' ); }
        $lifetime_days = (int) round( (int) get_option( 'zsg_auth_session_lifetime', 30 * 86400 ) / 86400 );
        if ( $lifetime_days < 1 ) { $lifetime_days = 30; }
        $max_devices   = (int) get_option( 'zsg_auth_max_devices', 5 );
        $login_id      = (int) get_option( 'zsg_auth_login_page_id', 0 );
        $pages         = get_pages( [ 'number' => 200 ] );
        ?>
        <div class="wrap" dir="rtl">
            <h1>تنظیمات امنیتی ZSG Auth</h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'zsg_auth_security' ); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="zsg_auth_session_lifetime">مدت اعتبار نشست (روز)</label></th>
                        <td>
                            <input type="number" id="zsg_auth_session_lifetime" name="zsg_auth_session_lifetime" value="<?php echo esc_attr( (string) $lifetime_days ); ?>" min="1" max="365" class="small-text" />
                            <p class="description">کاربر پس از این تعداد روز خودکار از حساب خارج می‌شود. پیش‌فرض ۳۰.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="zsg_auth_max_devices">حداکثر دستگاه همزمان</label></th>
                        <td>
                            <input type="number" id="zsg_auth_max_devices" name="zsg_auth_max_devices" value="<?php echo esc_attr( (string) $max_devices ); ?>" min="1" max="50" class="small-text" />
                            <p class="description">وقتی به این تعداد رسید، قدیمی‌ترین نشست خودکار بسته می‌شود. پیش‌فرض ۵.</p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row" colspan="2" style="padding-top:24px;">
                            <h2 style="margin:0;font-size:15px;border-top:1px solid #ddd;padding-top:16px;">تنظیمات کد OTP و کلیپ‌بورد</h2>
                        </th>
                    </tr>
                    <tr>
                        <th scope="row"><label for="zsg_auth_otp_length">طول کد OTP</label></th>
                        <td>
                            <?php $otp_len = (int) get_option( 'zsg_auth_otp_length', 6 ); ?>
                            <input type="number" id="zsg_auth_otp_length" name="zsg_auth_otp_length" value="<?php echo esc_attr( (string) $otp_len ); ?>" min="4" max="8" class="small-text" />
                            <p class="description">تعداد ارقام کد تأیید. اگر پیامک شما ۵ رقمی است، اینجا ۵ بگذارید.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="zsg_auth_otp_clipboard_enabled">خواندن خودکار از کلیپ‌بورد</label></th>
                        <td>
                            <?php $cb = (int) get_option( 'zsg_auth_otp_clipboard_enabled', 1 ); ?>
                            <label><input type="checkbox" id="zsg_auth_otp_clipboard_enabled" name="zsg_auth_otp_clipboard_enabled" value="1" <?php checked( $cb, 1 ); ?>> فعال</label>
                            <p class="description">وقتی مرحله OTP باز می‌شود، اگر کد پیامک در کلیپ‌بورد باشد و با الگوی زیر تطبیق کند، خودکار پر می‌شود.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="zsg_auth_otp_clipboard_pattern">الگوی کد در پیامک</label></th>
                        <td>
                            <?php $pat = (string) get_option( 'zsg_auth_otp_clipboard_pattern', 'Code: {code}' ); ?>
                            <textarea id="zsg_auth_otp_clipboard_pattern" name="zsg_auth_otp_clipboard_pattern" rows="3" class="large-text code" placeholder="Code: {code}"><?php echo esc_textarea( $pat ); ?></textarea>
                            <p class="description"><strong>مثال:</strong> <code>Code: {code}</code> — <code>{code}</code> جایگزین کد N رقمی می‌شود.</p>
                            <p class="description">اگر خالی باشد، خودکار این الگوها امتحان می‌شوند: <code>Code: XXX</code> ، <code>کد: XXX</code> ، <code>#XXX</code> ، <code>@domain #XXX</code></p>
                        </td>
                    </tr>
                                        <tr>
                        <th scope="row" colspan="2" style="padding-top:24px;">
                            <h2 style="margin:0;font-size:15px;border-top:1px solid #ddd;padding-top:16px;">Page Lock — قفل صفحات</h2>
                        </th>
                    </tr>
                    <tr>
                        <th scope="row"><label for="zsg_auth_login_page_id">صفحه‌ی ورود (redirect)</label></th>
                        <td>
                            <select id="zsg_auth_login_page_id" name="zsg_auth_login_page_id">
                                <option value="0">— انتخاب کنید —</option>
                                <?php foreach ( $pages as $pg ) : ?>
                                    <option value="<?php echo esc_attr( (string) $pg->ID ); ?>" <?php selected( $login_id, $pg->ID ); ?>>
                                        <?php echo esc_html( $pg->post_title ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">برگه‌ای که شورت‌کد <code>[zsg_auth_page]</code> دارد. برای حالت «ریدایرکت» استفاده می‌شود.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button( 'ذخیره تغییرات' ); ?>
            </form>
        </div>
        <?php
    }
}
