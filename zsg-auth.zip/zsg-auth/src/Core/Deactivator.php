<?php
declare(strict_types=1);
namespace ZSG\Auth\Core;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Deactivator {
    public static function deactivate(): void {
        $ts = wp_next_scheduled( 'zsg_auth_daily_cleanup' );
        if ( $ts ) { wp_unschedule_event( $ts, 'zsg_auth_daily_cleanup' ); }
        flush_rewrite_rules();
    }
}
