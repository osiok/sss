<?php
declare(strict_types=1);
namespace ZSG\Auth\Core;
use ZSG\Auth\Database\Migrator;
use ZSG\Auth\Support\Logger;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Plugin {
    private static ?self $instance = null;
    private bool $booted = false;

    public static function instance(): self {
        return self::$instance ??= new self();
    }
    private function __construct() {}

    public function boot(): void {
        if ( $this->booted ) { return; }
        $this->booted = true;

        load_plugin_textdomain( 'zsg-auth', false, dirname( ZSG_AUTH_BASENAME ) . '/languages' );

        $migrator = new Migrator();
        if ( $migrator->needs_migration() ) { $migrator->run(); }

        add_action( 'zsg_auth_daily_cleanup', [ $this, 'daily_cleanup' ] );

        if ( is_admin() ) { AdminMenu::instance()->register(); }

        \ZSG\Auth\Frontend\Assets::register();
        \ZSG\Auth\Frontend\Shortcode::register();
        \ZSG\Auth\Frontend\PageTemplate::register();
        \ZSG\Auth\Rest\Routes::register();
        \ZSG\Auth\Security\Logout::register();
        \ZSG\Auth\Access\PageLock::register();
        \ZSG\Auth\Access\Metabox::register();

        Logger::instance()->debug( 'Plugin booted', [ 'version' => ZSG_AUTH_VERSION ] );
    }

    public function daily_cleanup(): void {
        Logger::instance()->debug( 'Daily cleanup tick' );
    }
}
