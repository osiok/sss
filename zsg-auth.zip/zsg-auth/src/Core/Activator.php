<?php
declare(strict_types=1);
namespace ZSG\Auth\Core;
use ZSG\Auth\Database\Installer;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Activator {
    public static function activate(): void {
        if ( ! current_user_can( 'activate_plugins' ) ) { return; }
        Installer::install();
        update_option( 'zsg_auth_activated_at', time(), false );
        if ( ! wp_next_scheduled( 'zsg_auth_daily_cleanup' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'zsg_auth_daily_cleanup' );
        }
        flush_rewrite_rules();
    }
}
