<?php
declare(strict_types=1);
namespace ZSG\Auth\Rest;
use ZSG\Auth\Rest\Controllers\RequestOtpController;
use ZSG\Auth\Rest\Controllers\VerifyOtpController;
use ZSG\Auth\Rest\Controllers\RegisterController;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Routes {
    public static function register(): void {
        add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
    }

    public static function register_routes(): void {
        register_rest_route( 'zsg-auth/v1', '/request-otp', [
            'methods'             => 'POST',
            'callback'            => [ RequestOtpController::class, 'handle' ],
            'permission_callback' => '__return_true',
        ] );

        register_rest_route( 'zsg-auth/v1', '/verify-otp', [
            'methods'             => 'POST',
            'callback'            => [ VerifyOtpController::class, 'handle' ],
            'permission_callback' => '__return_true',
        ] );

        register_rest_route( 'zsg-auth/v1', '/register', [
            'methods'             => 'POST',
            'callback'            => [ RegisterController::class, 'handle' ],
            'permission_callback' => '__return_true',
        ] );
    }
}
