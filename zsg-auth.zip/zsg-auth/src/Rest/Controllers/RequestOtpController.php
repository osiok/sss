<?php
declare(strict_types=1);
namespace ZSG\Auth\Rest\Controllers;
use ZSG\Auth\Otp\OtpEngine;
use ZSG\Auth\Security\RateLimiter;
use ZSG\Auth\Support\Helpers;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class RequestOtpController {

    public static function handle( \WP_REST_Request $request ) {
        $params = $request->get_json_params() ?: $request->get_params();
        $phone_raw = isset( $params['phone'] ) ? (string) $params['phone'] : '';
        $phone = Helpers::normalize_phone( $phone_raw );

        if ( ! $phone ) {
            return new \WP_REST_Response( [
                'success' => false,
                'error'   => [ 'code' => 'invalid_phone', 'message' => 'شماره نامعتبر است' ],
            ], 400 );
        }

        $phone_key = Helpers::hash_identifier( $phone );
        $cooldown  = (int) get_option( 'zsg_auth_resend_cooldown', 60 );

        // Dedupe: if a valid OTP already exists for this phone (and no force flag),
        // return success without consuming rate limits. Fixes "edit → continue → 429".
        $force = ! empty( $params['force'] );
        if ( ! $force ) {
            $repo = new \ZSG\Auth\Otp\OtpRepository();
            if ( $repo->has_active( $phone, 'login' ) ) {
                return new \WP_REST_Response( [
                    'success' => true,
                    'data'    => [
                        'message'      => 'کد تأیید قبلی هنوز معتبر است',
                        'expires_in'   => (int) get_option( 'zsg_auth_otp_expiry', 120 ),
                        'masked_phone' => Helpers::mask_phone( $phone ),
                    ],
                ], 200 );
            }
        }

        // 1) Cooldown first (most user-facing)
        $rl_c = RateLimiter::attempt( $phone_key, 'resend_cooldown', 1, $cooldown );
        if ( ! $rl_c['allowed'] ) {
            return self::limit_response( $rl_c, 'کمی صبر کنید و دوباره تلاش کنید' );
        }

        // 2) Per-phone hourly
        $rl_h = RateLimiter::attempt( $phone_key, 'phone_hour', 3, 3600 );
        if ( ! $rl_h['allowed'] ) {
            return self::limit_response( $rl_h, 'سقف ارسال ساعتی این شماره پر شده است' );
        }

        // 3) Per-phone daily
        $rl_d = RateLimiter::attempt( $phone_key, 'phone_day', 5, 86400 );
        if ( ! $rl_d['allowed'] ) {
            return self::limit_response( $rl_d, 'سقف ارسال روزانه این شماره پر شده است' );
        }

        // 4) Per-IP (10 per 10min)
        $ip     = self::client_ip();
        $ip_key = hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) );
        $rl_ip  = RateLimiter::attempt( $ip_key, 'ip_request', 10, 600 );
        if ( ! $rl_ip['allowed'] ) {
            return self::limit_response( $rl_ip, 'تعداد درخواست‌های شما بیش از حد مجاز است' );
        }

        // 5) Generate + send
        $result = OtpEngine::create( $phone, 'login' );
        if ( empty( $result['success'] ) ) {
            return new \WP_REST_Response( [
                'success' => false,
                'error'   => [ 'code' => $result['error'] ?? 'server_error', 'message' => $result['message'] ?? 'خطای سرور' ],
            ], 500 );
        }

        return new \WP_REST_Response( [
            'success' => true,
            'data'    => [
                'message'      => 'کد تأیید ارسال شد',
                'expires_in'   => $result['expires_in'],
                'masked_phone' => $result['masked_phone'],
            ],
        ], 200 );
    }

    private static function limit_response( array $rl, string $message ): \WP_REST_Response {
        $resp = new \WP_REST_Response( [
            'success' => false,
            'error'   => [ 'code' => 'rate_limited', 'message' => $message, 'retry_after' => $rl['retry_after'] ],
        ], 429 );
        $resp->header( 'Retry-After', (string) $rl['retry_after'] );
        return $resp;
    }

    private static function client_ip(): string {
        $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
        return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
    }
}
