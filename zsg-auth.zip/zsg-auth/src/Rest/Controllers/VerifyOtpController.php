<?php
declare(strict_types=1);
namespace ZSG\Auth\Rest\Controllers;
use ZSG\Auth\Otp\OtpEngine;
use ZSG\Auth\Security\SessionManager;
use ZSG\Auth\Security\RateLimiter;
use ZSG\Auth\Support\Helpers;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class VerifyOtpController {

    public static function handle( \WP_REST_Request $request ) {
        $params = $request->get_json_params() ?: $request->get_params();
        $phone_raw = isset( $params['phone'] ) ? (string) $params['phone'] : '';
        $code_raw  = isset( $params['code'] ) ? (string) $params['code'] : '';
        $phone     = Helpers::normalize_phone( $phone_raw );

        if ( ! $phone ) {
            return new \WP_REST_Response( [
                'success' => false,
                'error'   => [ 'code' => 'invalid_phone', 'message' => 'شماره نامعتبر است' ],
            ], 400 );
        }

        // Per-IP verify limit (anti DoS): 20 in 15min
        $ip     = self::client_ip();
        $ip_key = hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) );
        $rl_ip  = RateLimiter::attempt( $ip_key, 'ip_verify', 20, 900 );
        if ( ! $rl_ip['allowed'] ) {
            $resp = new \WP_REST_Response( [
                'success' => false,
                'error'   => [ 'code' => 'rate_limited', 'message' => 'تعداد تلاش‌های شما بیش از حد مجاز است', 'retry_after' => $rl_ip['retry_after'] ],
            ], 429 );
            $resp->header( 'Retry-After', (string) $rl_ip['retry_after'] );
            return $resp;
        }

        $result = OtpEngine::verify( $phone, $code_raw, 'login' );
        if ( empty( $result['success'] ) ) {
            return new \WP_REST_Response( [
                'success' => false,
                'error'   => [ 'code' => $result['error'], 'message' => $result['message'] ],
            ], (int) ( $result['http_status'] ?? 401 ) );
        }

        $user_id = self::find_user_by_phone( $phone );
        $is_new  = ( null === $user_id );

        if ( ! $is_new ) {
            $sm = new SessionManager();
            $device = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
            $session_token = $sm->create( (int) $user_id, $device );
            setcookie( 'zsg_session', $session_token, [
                'expires'  => time() + (int) get_option( 'zsg_auth_session_lifetime', 30 * 86400 ),
                'path'     => COOKIEPATH ?: '/',
                'domain'   => COOKIE_DOMAIN ?: '',
                'secure'   => is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax',
            ] );
            wp_set_current_user( $user_id );
            wp_set_auth_cookie( $user_id, true, is_ssl() );
            return new \WP_REST_Response( [
                'success' => true,
                'data'    => [
                    'verified' => true,
                    'is_new'   => false,
                    'user_id'  => $user_id,
                ],
            ], 200 );
        }

        // New user — issue short-lived registration token
        $token = bin2hex( random_bytes( 16 ) );
        $tkey  = 'zsg_reg_' . hash_hmac( 'sha256', $phone, wp_salt( 'auth' ) );
        set_transient( $tkey, $token, 600 ); // 10 minutes

        return new \WP_REST_Response( [
            'success' => true,
            'data'    => [
                'verified'       => true,
                'is_new'         => true,
                'user_id'        => null,
                'register_token' => $token,
            ],
        ], 200 );
    }

    private static function find_user_by_phone( string $phone ): ?int {
        // Try our meta key first
        $users = get_users( [
            'meta_key'   => 'zsg_auth_phone',
            'meta_value' => $phone,
            'number'     => 1,
            'fields'     => 'ID',
        ] );
        if ( ! empty( $users ) ) { return (int) $users[0]; }

        // Try Digits meta if present
        $users = get_users( [
            'meta_key'   => 'digits_phone',
            'meta_value' => $phone,
            'number'     => 1,
            'fields'     => 'ID',
        ] );
        if ( ! empty( $users ) ) { return (int) $users[0]; }

        return null;
    }

    private static function client_ip(): string {
        $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
        return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
    }
}
