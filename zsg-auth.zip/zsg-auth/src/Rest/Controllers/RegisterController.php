<?php
declare(strict_types=1);
namespace ZSG\Auth\Rest\Controllers;
use ZSG\Auth\Security\RateLimiter;
use ZSG\Auth\Security\SessionManager;
use ZSG\Auth\Support\Helpers;
use ZSG\Auth\Support\Logger;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class RegisterController {

    public static function handle( \WP_REST_Request $request ) {
        $params = $request->get_json_params() ?: $request->get_params();
        $phone  = Helpers::normalize_phone( (string) ( $params['phone'] ?? '' ) );
        $token  = sanitize_text_field( (string) ( $params['token'] ?? '' ) );
        $first  = sanitize_text_field( (string) ( $params['first_name'] ?? '' ) );
        $last   = sanitize_text_field( (string) ( $params['last_name'] ?? '' ) );

        if ( ! $phone || ! $token || mb_strlen( $first ) < 2 ) {
            return new \WP_REST_Response( [
                'success' => false,
                'error'   => [ 'code' => 'invalid_input', 'message' => 'اطلاعات ناقص است' ],
            ], 400 );
        }

        // Rate limit
        $ip     = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
        $ip_key = hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) );
        $rl     = RateLimiter::attempt( $ip_key, 'ip_register', 5, 3600 );
        if ( ! $rl['allowed'] ) {
            $resp = new \WP_REST_Response( [
                'success' => false,
                'error'   => [ 'code' => 'rate_limited', 'message' => 'تعداد ثبت‌نام بیش از حد مجاز', 'retry_after' => $rl['retry_after'] ],
            ], 429 );
            $resp->header( 'Retry-After', (string) $rl['retry_after'] );
            return $resp;
        }

        // Validate token
        $tkey     = 'zsg_reg_' . hash_hmac( 'sha256', $phone, wp_salt( 'auth' ) );
        $expected = (string) get_transient( $tkey );
        if ( '' === $expected || ! hash_equals( $expected, $token ) ) {
            return new \WP_REST_Response( [
                'success' => false,
                'error'   => [ 'code' => 'invalid_token', 'message' => 'توکن نامعتبر یا منقضی شده است' ],
            ], 403 );
        }
        delete_transient( $tkey );

        // Guard: user must not exist
        $existing = get_users( [ 'meta_key' => 'zsg_auth_phone', 'meta_value' => $phone, 'number' => 1, 'fields' => 'ID' ] );
        if ( ! empty( $existing ) ) {
            return new \WP_REST_Response( [
                'success' => false,
                'error'   => [ 'code' => 'user_exists', 'message' => 'کاربر با این شماره وجود دارد' ],
            ], 409 );
        }

        // Username = phone with leading 0 (e.g. 0912777111)
        $local_phone = '0' . substr( $phone, 3 ); // +989121111111 → 09121111111
        if ( username_exists( $local_phone ) ) {
            // Race condition: someone registered between OTP verify and now
            return new \WP_REST_Response( [
                'success' => false,
                'error'   => [ 'code' => 'user_exists', 'message' => 'کاربر با این شماره وجود دارد' ],
            ], 409 );
        }

        $display = trim( $first . ' ' . $last ) ?: 'کاربر';
        $role    = (string) get_option( 'zsg_auth_default_role', 'customer' );
        if ( ! in_array( $role, [ 'subscriber', 'customer', 'contributor' ], true ) ) {
            $role = 'customer';
        }

        $user_id = wp_insert_user( [
            'user_login'   => $local_phone,
            'user_pass'    => wp_generate_password( 32, true, true ),
            'first_name'   => $first,
            'last_name'    => $last,
            'display_name' => $display,
            'role'         => $role,
            'user_email'   => $local_phone . '@no-email.zsg.local',
        ] );

        if ( is_wp_error( $user_id ) ) {
            Logger::instance()->error( 'Registration failed', [ 'error' => $user_id->get_error_message() ] );
            return new \WP_REST_Response( [
                'success' => false,
                'error'   => [ 'code' => 'create_failed', 'message' => 'ایجاد کاربر با خطا مواجه شد' ],
            ], 500 );
        }

        update_user_meta( (int) $user_id, 'zsg_auth_phone', $phone );
        update_user_meta( (int) $user_id, 'zsg_auth_phone_verified', '1' );
        update_user_meta( (int) $user_id, 'zsg_auth_phone_verified_at', time() );

        // Create session record + set auth cookie
        $sm = new SessionManager();
        $device = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
        $session_token = $sm->create( (int) $user_id, $device );
        setcookie( 'zsg_session', $session_token, [
            'expires'  => time() + (int) get_option( 'zsg_auth_session_lifetime', 30 * 86400 ),
            'path'     => COOKIEPATH ?: '/',
            'domain'   => COOKIE_DOMAIN ?: '',
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax',
        ] );

        wp_set_current_user( (int) $user_id );
        wp_set_auth_cookie( (int) $user_id, true, is_ssl() );

        Logger::instance()->info( 'User registered', [
            'user_id' => (int) $user_id,
            'phone'   => Helpers::mask_phone( $phone ),
        ] );

        return new \WP_REST_Response( [
            'success' => true,
            'data'    => [
                'user_id' => (int) $user_id,
                'message' => 'ثبت نام موفق!',
            ],
        ], 200 );
    }
}
