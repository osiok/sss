<?php
declare(strict_types=1);
namespace ZSG\Auth\Frontend;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Shortcode {
    public static function register(): void {
        add_shortcode( 'zsg_auth_form', [ __CLASS__, 'render_modal' ] );
        add_shortcode( 'zsg_auth_demo', [ __CLASS__, 'render_modal' ] );
        add_shortcode( 'zsg_auth_page', [ __CLASS__, 'render_page' ] );
    }

    public static function render_modal( $atts = [] ): string {
        $atts = shortcode_atts( [ 'trigger_text' => __( 'ورود / ثبت نام', 'zsg-auth' ) ], $atts, 'zsg_auth_form' );
        Assets::enqueue();
        ob_start();
        include ZSG_AUTH_PATH . 'src/Frontend/Views/modal.php';
        return (string) ob_get_clean();
    }

    public static function render_page( $atts = [] ): string {
        Assets::enqueue();
        ob_start();
        include ZSG_AUTH_PATH . 'src/Frontend/Views/page.php';
        return (string) ob_get_clean();
    }
}
