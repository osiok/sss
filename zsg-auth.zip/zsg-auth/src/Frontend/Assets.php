<?php
declare(strict_types=1);
namespace ZSG\Auth\Frontend;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Assets {
    private static bool $registered = false;

    public static function register(): void {
        // Priority 999 → loads AFTER theme CSS
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'maybe_enqueue' ], 999 );
    }

    public static function maybe_enqueue(): void {
        if ( is_singular() ) { self::enqueue(); }
    }

    public static function enqueue(): void {
        if ( self::$registered ) { return; }
        self::$registered = true;

        wp_enqueue_style( 'zsg-auth-design-system', ZSG_AUTH_URL . 'assets/css/design-system.css', [], ZSG_AUTH_VERSION . '.76' );
        wp_enqueue_style( 'zsg-auth-frontend',      ZSG_AUTH_URL . 'assets/css/frontend.css', [ 'zsg-auth-design-system' ], ZSG_AUTH_VERSION . '.76' );

        // Critical inline overrides — loaded AFTER all stylesheets
        $critical = self::critical_css();
        wp_add_inline_style( 'zsg-auth-frontend', $critical );
    }

    private static function critical_css(): string {
        return <<<CSS
/* ZSG Auth — CRITICAL OVERRIDES (loaded after theme CSS) */
body .zsg-root button.zsg-btn,
body .zsg-root a.zsg-btn,
body .zsg-root button,
body .zsg-root a.zsg-btn:link,
body .zsg-root a.zsg-btn:visited {
  -webkit-appearance: none !important;
  appearance: none !important;
  background-image: none !important;
  background-clip: border-box !important;
  text-shadow: none !important;
  text-transform: none !important;
  letter-spacing: normal !important;
  word-spacing: normal !important;
  text-decoration: none !important;
  outline: 0 !important;
  box-shadow: none !important;
  font-family: inherit !important;
  font-synthesis: none !important;
}
body .zsg-root .zsg-btn {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  gap: 6px !important;
  height: 40px !important;
  min-height: 40px !important;
  max-height: 40px !important;
  padding: 0 16px !important;
  margin: 0 !important;
  border-radius: 8px !important;
  border: 1px solid transparent !important;
  font-size: 14px !important;
  font-weight: 600 !important;
  line-height: 1 !important;
  cursor: pointer !important;
  transition: background-color 150ms ease, border-color 150ms ease, box-shadow 150ms ease !important;
}
body .zsg-root .zsg-btn-primary {
  background-color: #3b82f6 !important;
  background-image: none !important;
  color: #ffffff !important;
  border-color: #3b82f6 !important;
  width: 100% !important;
}
body .zsg-root .zsg-btn-primary:not(:disabled):hover {
  background-color: #2563eb !important;
  border-color: #2563eb !important;
  color: #ffffff !important;
}
body .zsg-root .zsg-btn-primary:not(:disabled):active {
  background-color: #1d4ed8 !important;
  border-color: #1d4ed8 !important;
  color: #ffffff !important;
}
body .zsg-root .zsg-btn-primary:disabled {
  background-color: #3b82f6 !important;
  border-color: #3b82f6 !important;
  color: #ffffff !important;
  opacity: 0.5 !important;
  cursor: not-allowed !important;
}
body .zsg-root .zsg-btn-secondary {
  background-color: #2e2e2e !important;
  color: #f1f5f9 !important;
  border-color: #3a3a3a !important;
}
body .zsg-root .zsg-btn-secondary:not(:disabled):hover {
  background-color: #3a3a3a !important;
}
body .zsg-root .zsg-btn-destructive {
  background-color: #dc2626 !important;
  color: #ffffff !important;
  border-color: #dc2626 !important;
  width: 100% !important;
}
body .zsg-root .zsg-btn-destructive:not(:disabled):hover {
  background-color: #b91c1c !important;
  border-color: #b91c1c !important;
  color: #ffffff !important;
}
body .zsg-root .zsg-btn-ghost {
  background-color: transparent !important;
  color: #94a3b8 !important;
  border-color: #3a3a3a !important;
}
body .zsg-root .zsg-btn-ghost:not(:disabled):hover {
  background-color: #2e2e2e !important;
  color: #f1f5f9 !important;
  border-color: #4a4a4a !important;
}
body .zsg-root .zsg-btn:focus-visible {
  outline: 0 !important;
  box-shadow: 0 0 0 3px rgba(59,130,246,.45) !important;
}

/* INPUTS — full reset from theme */
body .zsg-root input[type="text"],
body .zsg-root input[type="tel"],
body .zsg-root input[type="email"],
body .zsg-root input[type="password"],
body .zsg-root input:not([type]) {
  -webkit-appearance: none !important;
  appearance: none !important;
  background: #2e2e2e !important;
  background-image: none !important;
  background-color: #2e2e2e !important;
  color: #f1f5f9 !important;
  border: 1px solid #3a3a3a !important;
  border-radius: 8px !important;
  height: 40px !important;
  min-height: 40px !important;
  line-height: 1 !important;
  padding: 0 12px !important;
  margin: 0 !important;
  font-family: inherit !important;
  font-size: 14px !important;
  font-weight: 400 !important;
  box-shadow: none !important;
  outline: 0 !important;
  transition: border-color 150ms ease, box-shadow 150ms ease !important;
  text-shadow: none !important;
  box-sizing: border-box !important;
  width: 100% !important;
  -webkit-text-fill-color: #f1f5f9 !important;
}
body .zsg-root input[type="text"]::placeholder,
body .zsg-root input[type="tel"]::placeholder,
body .zsg-root input[type="email"]::placeholder,
body .zsg-root input[type="password"]::placeholder,
body .zsg-root input:not([type])::placeholder {
  color: #94a3b8 !important;
  -webkit-text-fill-color: #94a3b8 !important;
  opacity: 1 !important;
}
body .zsg-root input[type="text"]:focus,
body .zsg-root input[type="tel"]:focus,
body .zsg-root input[type="email"]:focus,
body .zsg-root input[type="password"]:focus,
body .zsg-root input:not([type]):focus {
  border-color: #3b82f6 !important;
  box-shadow: 0 0 0 3px rgba(59,130,246,.35) !important;
  outline: 0 !important;
}
body .zsg-root input:-webkit-autofill,
body .zsg-root input:-webkit-autofill:hover,
body .zsg-root input:-webkit-autofill:focus {
  -webkit-box-shadow: 0 0 0 1000px #2e2e2e inset !important;
  -webkit-text-fill-color: #f1f5f9 !important;
  caret-color: #f1f5f9 !important;
  transition: background-color 9999s ease-in-out 0s !important;
}

/* PHONE GROUP — full reset from theme hover/focus */
body .zsg-root .zsg-phone-group {
  display: flex !important;
  align-items: stretch !important;
  flex-direction: row !important;
  direction: ltr !important;
  background: #2e2e2e !important;
  background-image: none !important;
  border: 1px solid #3a3a3a !important;
  border-radius: 8px !important;
  overflow: hidden !important;
  height: 40px !important;
  min-height: 40px !important;
  padding: 0 !important;
  margin: 0 !important;
  box-shadow: none !important;
  outline: 0 !important;
  transition: border-color 150ms ease, box-shadow 150ms ease !important;
}
body .zsg-root .zsg-phone-group:hover {
  background: #2e2e2e !important;
  border-color: #3a3a3a !important;
  box-shadow: none !important;
}
body .zsg-root .zsg-phone-group:focus-within {
  border-color: #3b82f6 !important;
  box-shadow: 0 0 0 3px rgba(59,130,246,.35) !important;
}
body .zsg-root .zsg-phone-group .zsg-phone-prefix {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  padding: 0 12px !important;
  margin: 0 !important;
  font-size: 14px !important;
  color: #94a3b8 !important;
  border: 0 !important;
  border-right: 1px solid #3a3a3a !important;
  background: #242424 !important;
  direction: ltr !important;
  flex: 0 0 auto !important;
  font-feature-settings: "tnum" !important;
  line-height: 1 !important;
  height: 100% !important;
  box-shadow: none !important;
}
body .zsg-root .zsg-phone-group input[type="tel"],
body .zsg-root .zsg-phone-group input[type="text"] {
  flex: 1 1 auto !important;
  min-width: 0 !important;
  height: 100% !important;
  min-height: 0 !important;
  padding: 0 12px !important;
  margin: 0 !important;
  border: 0 !important;
  border-radius: 0 !important;
  background: transparent !important;
  background-color: transparent !important;
  background-image: none !important;
  box-shadow: none !important;
  outline: 0 !important;
  color: #f1f5f9 !important;
  -webkit-text-fill-color: #f1f5f9 !important;
  direction: ltr !important;
  text-align: left !important;
  font-size: 14px !important;
  font-feature-settings: "tnum" !important;
  font-family: inherit !important;
  font-weight: 400 !important;
  line-height: 1 !important;
  -webkit-appearance: none !important;
  appearance: none !important;
}
body .zsg-root .zsg-phone-group input:hover,
body .zsg-root .zsg-phone-group input:focus,
body .zsg-root .zsg-phone-group input:active {
  background: transparent !important;
  background-color: transparent !important;
  border-color: transparent !important;
  box-shadow: none !important;
  outline: 0 !important;
}

/* OTP inputs — reset from theme */
body .zsg-root .zsg-otp-input {
  -webkit-appearance: none !important;
  appearance: none !important;
  background: #2e2e2e !important;
  background-color: #2e2e2e !important;
  background-image: none !important;
  color: #f1f5f9 !important;
  -webkit-text-fill-color: #f1f5f9 !important;
  border: 1px solid #3a3a3a !important;
  border-radius: 8px !important;
  height: 48px !important;
  min-height: 48px !important;
  width: 40px !important;
  padding: 0 !important;
  margin: 0 !important;
  font-size: 18px !important;
  font-weight: 600 !important;
  text-align: center !important;
  line-height: 1 !important;
  box-shadow: none !important;
  outline: 0 !important;
  transition: border-color 150ms ease, box-shadow 150ms ease !important;
  font-feature-settings: "tnum" !important;
  font-family: inherit !important;
}
body .zsg-root .zsg-otp-input:hover {
  background: #2e2e2e !important;
  border-color: #3a3a3a !important;
  box-shadow: none !important;
}
body .zsg-root .zsg-otp-input:focus {
  background: #2e2e2e !important;
  border-color: #3b82f6 !important;
  box-shadow: 0 0 0 3px rgba(59,130,246,.35) !important;
  outline: 0 !important;
}

/* EDIT PHONE — full reset */
body .zsg-root button.zsg-edit-phone,
body .zsg-root .zsg-edit-phone {
  -webkit-appearance: none !important;
  appearance: none !important;
  background: transparent !important;
  background-image: none !important;
  background-color: transparent !important;
  border: 0 !important;
  padding: 2px 4px !important;
  margin: 0 2px !important;
  color: #3b82f6 !important;
  font-family: inherit !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  cursor: pointer !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  gap: 4px !important;
  vertical-align: middle !important;
  box-shadow: none !important;
  outline: 0 !important;
  text-decoration: none !important;
  text-shadow: none !important;
  text-transform: none !important;
  height: auto !important;
  min-height: 0 !important;
  line-height: 1 !important;
  border-radius: 4px !important;
  transition: background-color 120ms ease, color 120ms ease !important;
}
body .zsg-root button.zsg-edit-phone:hover,
body .zsg-root .zsg-edit-phone:hover {
  background: rgba(59,130,246,.1) !important;
  color: #2563eb !important;
  box-shadow: none !important;
  border: 0 !important;
}
body .zsg-root button.zsg-edit-phone:focus-visible,
body .zsg-root .zsg-edit-phone:focus-visible {
  outline: 0 !important;
  box-shadow: 0 0 0 2px rgba(59,130,246,.5) !important;
}
body .zsg-root .zsg-edit-phone svg {
  width: 12px !important;
  height: 12px !important;
  stroke: currentColor !important;
  fill: none !important;
  display: inline-block !important;
  vertical-align: middle !important;
}

/* RESEND — full reset + centered */
body .zsg-root button.zsg-resend,
body .zsg-root .zsg-resend {
  -webkit-appearance: none !important;
  appearance: none !important;
  background: transparent !important;
  background-image: none !important;
  background-color: transparent !important;
  border: 0 !important;
  border-radius: 4px !important;
  padding: 4px 8px !important;
  margin: 0 !important;
  color: #3b82f6 !important;
  font-family: inherit !important;
  font-size: 13px !important;
  font-weight: 500 !important;
  cursor: pointer !important;
  display: inline-block !important;
  text-decoration: none !important;
  text-shadow: none !important;
  text-transform: none !important;
  letter-spacing: normal !important;
  box-shadow: none !important;
  outline: 0 !important;
  height: auto !important;
  min-height: 0 !important;
  line-height: 1.6 !important;
  transition: color 120ms ease, background-color 120ms ease !important;
  white-space: nowrap !important;
  word-spacing: normal !important;
}
body .zsg-root button.zsg-resend:hover,
body .zsg-root .zsg-resend:hover {
  background: rgba(59,130,246,.08) !important;
  color: #2563eb !important;
}
body .zsg-root button.zsg-resend:disabled,
body .zsg-root .zsg-resend:disabled {
  color: #94a3b8 !important;
  cursor: not-allowed !important;
  background: transparent !important;
}
body .zsg-root .zsg-otp-meta {
  display: flex !important;
  justify-content: center !important;
  align-items: center !important;
  text-align: center !important;
  margin: 14px 0 4px !important;
  padding: 0 !important;
  width: 100% !important;
}
body .zsg-root .zsg-otp-meta .zsg-resend [data-zsg-countdown] {
  display: inline-block !important;
  min-width: 22px !important;
  text-align: center !important;
  font-feature-settings: "tnum" !important;
  font-weight: 600 !important;
  margin: 0 4px !important;
  vertical-align: middle !important;
}
CSS;
    }
}
