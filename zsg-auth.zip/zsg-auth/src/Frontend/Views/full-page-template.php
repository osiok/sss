<?php
/**
 * ZSG Auth — Full Page Template
 * Used only for pages that contain [zsg_auth_page].
 * Renders without theme header/footer/breadcrumbs.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>
<?php wp_head(); ?>
<style>
  html, body { margin: 0 !important; padding: 0 !important; background: #1a1a1a !important; overflow-x: hidden !important; }
  body { min-height: 100vh !important; }
</style>
</head>
<body <?php body_class( 'zsg-full-page' ); ?>>
<main class="zsg-full-page-main">
<?php
while ( have_posts() ) {
    the_post();
    the_content();
}
?>
</main>
<?php wp_footer(); ?>
</body>
</html>
