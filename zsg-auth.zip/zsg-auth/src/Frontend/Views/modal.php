<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$args = $args ?? array();
$force_open = ! empty( $args['force_open'] );
$trigger_text = isset( $args['trigger_text'] ) ? $args['trigger_text'] : __( 'ورود / ثبت نام', 'zsg-auth' );
$uid = 'zsg-m-' . wp_unique_id();
$rest = esc_url_raw( rest_url( 'zsg-auth/v1' ) );
?>
<div class="zsg-root" id="<?php echo esc_attr( $uid ); ?>" data-version="76" dir="rtl">

<?php if ( is_user_logged_in() ) : ?>
  <a href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/acc/' ) ); ?>" class="zsg-btn zsg-btn-primary" style="width:auto;padding:0 20px;display:inline-flex;text-decoration:none;">
    حساب کاربری
  </a>
<?php else : ?>

  <?php if ( ! $force_open ) : ?>
  <button type="button" class="zsg-btn zsg-btn-primary" data-zsg-open style="width:auto;padding:0 20px;">
    <?php echo esc_html( $trigger_text ); ?>
  </button>
  <?php endif; ?>

  <div class="zsg-modal-overlay" <?php echo $force_open ? 'data-open="1"' : 'hidden'; ?> role="dialog" aria-modal="true">
    <div class="zsg-modal">
      <?php if ( ! $force_open ) : ?>
      <button type="button" class="zsg-modal-close" aria-label="بستن">&times;</button>
      <?php endif; ?>

      <div class="zsg-step" data-step="phone">
        <h2 class="zsg-modal-title">ورود و ثبت نام</h2>
        <p class="zsg-modal-desc">برای ادامه لطفاً شماره موبایل خود را وارد کنید</p>
        <div class="zsg-phone-group">
          <span class="zsg-phone-prefix">+98</span>
          <input type="tel" inputmode="numeric" autocomplete="tel-national" placeholder="911*******" data-zsg-phone maxlength="13" aria-label="شماره موبایل">
        </div>
        <div class="zsg-actions">
          <button type="button" class="zsg-btn zsg-btn-primary" data-zsg-continue disabled>
            <span class="zsg-btn-label">ادامه</span>
          </button>
        </div>
      </div>

      <div class="zsg-step" data-step="otp" hidden>
        <h2 class="zsg-modal-title">تأیید شماره موبایل</h2>
        <p class="zsg-modal-desc">
          کد ارسال‌شده به <span class="zsg-phone-strong" data-zsg-phone-display></span> را وارد کنید
          <button type="button" class="zsg-edit-phone" data-zsg-edit-phone aria-label="ویرایش شماره">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="12" height="12"><path d="M11 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22H15C20 22 22 20 22 15V13"/><path d="M16.04 3.02001L8.16 10.9C7.86 11.2 7.56 11.79 7.5 12.22L7.07 15.23C6.91 16.32 7.68 17.08 8.77 16.93L11.78 16.5C12.2 16.44 12.79 16.14 13.1 15.84L20.98 7.96001C22.34 6.60001 22.98 5.02001 20.98 3.02001C18.98 1.02001 17.4 1.66001 16.04 3.02001Z"/></svg>
          </button>
        </p>
        <div class="zsg-otp-inputs">
          <input type="tel" inputmode="numeric" class="zsg-otp-input" autocomplete="one-time-code" aria-label="رقم ۱">
          <input type="tel" inputmode="numeric" class="zsg-otp-input" aria-label="رقم ۲">
          <input type="tel" inputmode="numeric" class="zsg-otp-input" aria-label="رقم ۳">
          <input type="tel" inputmode="numeric" class="zsg-otp-input" aria-label="رقم ۴">
          <input type="tel" inputmode="numeric" class="zsg-otp-input" aria-label="رقم ۵">
          <input type="tel" inputmode="numeric" class="zsg-otp-input" aria-label="رقم ۶">
        </div>
        <div class="zsg-otp-meta">
          <button type="button" class="zsg-resend" data-zsg-resend disabled>ارسال مجدد تا <span style="display:inline-block;margin:0 4px;min-width:20px;text-align:center;">60</span> ثانیه</button>
        </div>
        <p class="zsg-hint" data-zsg-hint hidden>اگر پیامک را دریافت نکردین پوشه اسپم را بررسی کنید.</p>
      </div>

      <div class="zsg-step" data-step="name" hidden>
        <h2 class="zsg-modal-title">تکمیل ثبت نام</h2>
        <p class="zsg-modal-desc">نام و نام خانوادگی خود را وارد کنید</p>
        <div class="zsg-name-fields">
          <input type="text" data-zsg-fullname placeholder="نام و نام خانوادگی" maxlength="120">
        </div>
        <div class="zsg-actions">
          <button type="button" class="zsg-btn zsg-btn-primary" data-zsg-register disabled>
            <span class="zsg-btn-label">تکمیل ثبت نام</span>
          </button>
        </div>
      </div>

    </div>
  </div>

  <div class="zsg-toast-container"></div>
<?php endif; ?>
</div>
<?php if ( ! is_user_logged_in() ) : ?>
<script>
window.ZSG_AUTH_CFG = <?php
$zsg_len = (int) get_option( 'zsg_auth_otp_length', 6 );
if ( $zsg_len < 4 || $zsg_len > 8 ) { $zsg_len = 6; }
$zsg_pat = (string) get_option( 'zsg_auth_otp_clipboard_pattern', 'Code: {code}' );
$zsg_cb  = (int) get_option( 'zsg_auth_otp_clipboard_enabled', 1 );
$zsg_dom = wp_parse_url( home_url(), PHP_URL_HOST );
echo wp_json_encode( array(
  'otpLength'        => $zsg_len,
  'clipboardEnabled' => (bool) $zsg_cb,
  'clipboardPattern' => $zsg_pat,
  'homeDomain'       => (string) $zsg_dom,
) );
?>;
</script>

<script>
(function(){

var ROOT_ID = <?php echo wp_json_encode( $uid ); ?>;
var REST = <?php echo wp_json_encode( $rest ); ?>;
var FORCE_OPEN = <?php echo $force_open ? "true" : "false"; ?>;

var CFG = window.ZSG_AUTH_CFG || { otpLength: 6, clipboardEnabled: true, clipboardPattern: 'Code: {code}', homeDomain: '' };
var OTP_LEN = parseInt(CFG.otpLength, 10) || 6;
if (OTP_LEN < 4 || OTP_LEN > 8) OTP_LEN = 6;

var root = document.getElementById(ROOT_ID);
if (!root) { return; }
if (root.getAttribute('data-wired') === '1') { return; }
root.setAttribute('data-wired', '1');

var overlay = root.querySelector('.zsg-modal-overlay');
var closeBtn = root.querySelector('.zsg-modal-close');
var openBtns = root.querySelectorAll('[data-zsg-open]');
var phoneInput = root.querySelector('[data-zsg-phone]');
var continueBtn = root.querySelector('[data-zsg-continue]');
var phoneDisplay = root.querySelector('[data-zsg-phone-display]');
var stepPhone = root.querySelector('[data-step="phone"]');
var stepOtp = root.querySelector('[data-step="otp"]');
var stepName = root.querySelector('[data-step="name"]');
var resendBtn = root.querySelector('[data-zsg-resend]');
var hintEl = root.querySelector('[data-zsg-hint]');
var editBtn = root.querySelector('[data-zsg-edit-phone]');
var fullName = root.querySelector('[data-zsg-fullname]');
var registerBtn = root.querySelector('[data-zsg-register]');
var otpInputs = root.querySelectorAll('.zsg-otp-input');

var FA_MAP = {"۰":"0","۱":"1","۲":"2","۳":"3","۴":"4","۵":"5","۶":"6","۷":"7","۸":"8","۹":"9","٠":"0","١":"1","٢":"2","٣":"3","٤":"4","٥":"5","٦":"6","٧":"7","٨":"8","٩":"9"};
function toEn(s){ return String(s).replace(/[۰-۹٠-٩]/g, function(c){ return FA_MAP[c] || c; }); }
function onlyDigits(s){ return toEn(s).replace(/[^0-9]/g, ''); }
function normalizePhone(s){
  s = onlyDigits(s);
  if (s.length > 1 && s.charAt(0) === '0') s = s.slice(1);
  return s.slice(0, 10);
}
function formatPhone(s){
  if (s.length <= 3) return s;
  if (s.length <= 6) return s.slice(0,3) + ' ' + s.slice(3);
  return s.slice(0,3) + ' ' + s.slice(3,6) + ' ' + s.slice(6);
}
function toE164(d){ return (d.length === 10 && d.charAt(0) === '9') ? ('+98' + d) : ''; }

function updateContinue(){
  if (!continueBtn) return;
  var d = normalizePhone(phoneInput ? phoneInput.value : '');
  continueBtn.disabled = !(d.length === 10 && d.charAt(0) === '9');
}

function toast(msg, type){
  try {
    type = type || 'info';
    var MAP = {
      success: { c:'#22c55e', rgb:'34,197,94', label:'موفق' },
      error:   { c:'#ef4444', rgb:'239,68,68', label:'خطا' },
      warning: { c:'#f59e0b', rgb:'245,158,11', label:'هشدار' },
      info:    { c:'#3b82f6', rgb:'59,130,246', label:'اطلاع' }
    };
    var s = MAP[type] || MAP.info;
    var host = document.getElementById('zsg-toast-host');
    if (!host) {
      host = document.createElement('div');
      host.id = 'zsg-toast-host';
      host.style.cssText = 'position:fixed;top:16px;right:16px;left:auto;bottom:auto;z-index:2147483647;display:flex;flex-direction:column;gap:8px;pointer-events:none;max-width:380px;direction:rtl;';
      document.body.appendChild(host);
    }
    var el = document.createElement('div');
    el.style.cssText = 'pointer-events:auto;display:flex;align-items:flex-start;gap:10px;width:340px;max-width:calc(100vw - 32px);min-height:56px;padding:12px 14px;border-radius:12px;background:rgba(30,30,35,0.72);-webkit-backdrop-filter:blur(22px) saturate(180%);backdrop-filter:blur(22px) saturate(180%);border:1px solid rgba(' + s.rgb + ',0.28);box-shadow:inset 0 0 40px rgba(' + s.rgb + ',0.10),0 8px 28px rgba(0,0,0,.45);color:#f5f5f5;font-size:13px;line-height:1.5;direction:rtl;cursor:pointer;opacity:0;transition:opacity .2s;box-sizing:border-box;';
    var tt = document.createElement('div');
    tt.style.cssText = 'flex:1 1 auto;min-width:0;';
    var t1 = document.createElement('div');
    t1.style.cssText = 'font-weight:700;font-size:12.5px;margin:0 0 3px 0;color:#f5f5f5;';
    t1.textContent = s.label;
    var t2 = document.createElement('div');
    t2.style.cssText = 'font-size:12px;color:#c0c0c0;line-height:1.55;margin:0;';
    t2.textContent = String(msg);
    tt.appendChild(t1); tt.appendChild(t2);
    var cb = document.createElement('button');
    cb.type = 'button';
    cb.style.cssText = 'flex:0 0 auto;width:22px;height:22px;border:0;background:transparent;color:#7a7a7a;font-size:16px;cursor:pointer;padding:0;line-height:1;font-family:Arial,sans-serif;';
    cb.textContent = '\u00D7';
    var done = false;
    function close(){ if (done) return; done = true; el.style.opacity = '0'; setTimeout(function(){ if (el.parentNode) el.parentNode.removeChild(el); }, 200); }
    cb.addEventListener('click', function(e){ e.stopPropagation(); close(); });
    el.addEventListener('click', close);
    el.appendChild(tt); el.appendChild(cb);
    host.appendChild(el);
    requestAnimationFrame(function(){ el.style.opacity = '1'; });
    setTimeout(close, 3200);
  } catch (e) { if (window.console) console.error('[ZSG] toast', e); }
}

function openModal(){
  if (!overlay) return;
  overlay.removeAttribute('hidden');
  overlay.setAttribute('data-open', '1');
  document.body.classList.add('zsg-modal-open');
  if (phoneInput) setTimeout(function(){ try { phoneInput.focus({preventScroll:true}); } catch(e){} }, 60);
}
function closeModal(){
  if (!overlay || FORCE_OPEN) return;
  overlay.setAttribute('data-open', '0');
  document.body.classList.remove('zsg-modal-open');
  setTimeout(function(){ overlay.setAttribute('hidden', ''); }, 200);
}

if (phoneInput) {
  phoneInput.addEventListener('input', function(){
    var d = normalizePhone(phoneInput.value);
    phoneInput.value = formatPhone(d);
    updateContinue();
  });
  phoneInput.addEventListener('keydown', function(e){
    if (e.key === 'Enter' && continueBtn && !continueBtn.disabled) { e.preventDefault(); continueBtn.click(); }
  });
}

var _inFlight = false;
function requestOtp(force){
  if (!continueBtn || _inFlight) return;
  var d = normalizePhone(phoneInput ? phoneInput.value : '');
  if (d.length !== 10 || d.charAt(0) !== '9') return;
  var e164 = toE164(d);
  if (!e164) return;
  _inFlight = true;
  continueBtn.classList.add('zsg-loading');
  continueBtn.disabled = true;
  var payload = { phone: e164 };
  if (force) payload.force = true;
  fetch(REST + '/request-otp', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    body: JSON.stringify(payload)
  }).then(function(r){ return r.json().then(function(j){ return {status: r.status, body: j}; }); })
  .then(function(res){
    _inFlight = false;
    continueBtn.classList.remove('zsg-loading');
    continueBtn.disabled = false;
    if (res.status === 200 && res.body.success) {
      if (phoneDisplay) phoneDisplay.textContent = res.body.data.masked_phone;
      if (stepPhone) stepPhone.hidden = true;
      if (stepOtp) stepOtp.hidden = false;
      if (stepName) stepName.hidden = true;
      toast(res.body.data.message || 'کد تأیید ارسال شد', 'success');
      if (otpInputs && otpInputs[0]) setTimeout(function(){ try { otpInputs[0].focus({preventScroll:true}); } catch(e){} }, 80);
      startResend(res.body.data.expires_in || 60);
      scheduleHint();
    } else if (res.status === 429) {
      var retry = (res.body.error && res.body.error.retry_after) || 60;
      toast((res.body.error && res.body.error.message) || 'کمی صبر کنید', 'warning');
      startResend(retry);
    } else {
      toast((res.body.error && res.body.error.message) || 'خطا در ارسال کد', 'error');
    }
  }).catch(function(){
    _inFlight = false;
    continueBtn.classList.remove('zsg-loading');
    continueBtn.disabled = false;
    toast('خطای شبکه', 'error');
  });
}

if (continueBtn) continueBtn.addEventListener('click', function(e){ e.preventDefault(); requestOtp(false); });
if (resendBtn) resendBtn.addEventListener('click', function(e){ e.preventDefault(); if (resendBtn.disabled) return; requestOtp(true); });
if (editBtn) editBtn.addEventListener('click', function(e){
  e.preventDefault();
  clearOtp();
  if (stepPhone) stepPhone.hidden = false;
  if (stepOtp) stepOtp.hidden = true;
  if (stepName) stepName.hidden = true;
  updateContinue();
  if (phoneInput) { try { phoneInput.focus({preventScroll:true}); } catch(err){} }
});

function collectOtp(){ var s = ''; for (var i = 0; i < otpInputs.length; i++) s += (otpInputs[i].value || ''); return s; }
function clearOtp(){ for (var i = 0; i < otpInputs.length; i++) otpInputs[i].value = ''; if (otpInputs[0]) try { otpInputs[0].focus({preventScroll:true}); } catch(e){} }
function distributeOtp(d){
  d = (d || '').replace(/[^0-9]/g, '').slice(0, otpInputs.length);
  if (!d) return;
  for (var i = 0; i < otpInputs.length; i++) otpInputs[i].value = d.charAt(i) || '';
  if (d.length === otpInputs.length) submitOtp(d);
  else if (otpInputs[d.length]) try { otpInputs[d.length].focus({preventScroll:true}); } catch(e){}
}

for (var oi = 0; oi < otpInputs.length; oi++) {
  (function(inp, idx){
    inp.addEventListener('input', function(){
      var v = (inp.value || '').replace(/[^0-9]/g, '');
      if (v.length > 1) { inp.value = ''; distributeOtp(v); return; }
      inp.value = v;
      if (v && idx < otpInputs.length - 1) try { otpInputs[idx + 1].focus({preventScroll:true}); } catch(e){}
      if (collectOtp().length === otpInputs.length) submitOtp(collectOtp());
    });
    inp.addEventListener('keydown', function(e){
      if (e.key === 'Backspace' && !inp.value && idx > 0) {
        e.preventDefault();
        otpInputs[idx - 1].value = '';
        try { otpInputs[idx - 1].focus({preventScroll:true}); } catch(e2){}
      } else if (e.key === 'ArrowLeft' && idx > 0) { otpInputs[idx - 1].focus(); }
      else if (e.key === 'ArrowRight' && idx < otpInputs.length - 1) { otpInputs[idx + 1].focus(); }
    });
    inp.addEventListener('paste', function(e){
      var t = '';
      if (e.clipboardData) t = e.clipboardData.getData('text');
      else if (window.clipboardData) t = window.clipboardData.getData('Text');
      if (!t) return;
      var code = extractOtp(t);
      if (!code) {
        var dOnly = t.replace(/[^0-9]/g, '');
        if (dOnly.length === OTP_LEN) code = dOnly;
      }
      if (!code) return;
      e.preventDefault();
      distributeOtp(code);
    });
    inp.addEventListener('focus', function(){ try { inp.select(); } catch(e){} });
  })(otpInputs[oi], oi);
}

function escapeRe(s){ return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
var OTP_REGEXES = (function(){
  var arr = [], N = OTP_LEN, dN = '\\d{' + N + '}';
  var pat = (CFG.clipboardPattern || '').trim();
  if (pat && pat.indexOf('{code}') !== -1) {
    try {
      var parts = pat.split('{code}'), esc = parts.map(escapeRe);
      var body = esc[0] + '\\s*(' + dN + ')';
      for (var k = 1; k < esc.length; k++) body += '\\s*' + esc[k];
      arr.push(new RegExp(body, 'i'));
    } catch (e) {}
  }
  arr.push(new RegExp('(?:Code|code|CODE|کد|رمز)\\s*[:：]?\\s*(' + dN + ')'));
  arr.push(new RegExp('#(' + dN + ')'));
  if (CFG.homeDomain) arr.push(new RegExp('@' + escapeRe(CFG.homeDomain) + '\\s+#(' + dN + ')', 'i'));
  return arr;
})();

function extractOtp(text){
  if (!text) return '';
  for (var i = 0; i < OTP_REGEXES.length; i++) {
    try {
      var m = text.match(OTP_REGEXES[i]);
      if (m) for (var g = 1; g < m.length; g++) if (m[g] && m[g].length === OTP_LEN) return m[g];
    } catch (e) {}
  }
  return '';
}
function hashStr(s){ var h = 5381; for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return String(h); }

var _lastHash = '', _apInFlight = false, _apLast = 0;
function tryAutoPaste(){
  if (!CFG.clipboardEnabled) return;
  if (_apInFlight) return;
  if (!navigator.clipboard || !navigator.clipboard.readText) return;
  if (!stepOtp || stepOtp.hidden) return;
  var now = Date.now();
  if (now - _apLast < 400) return;
  _apLast = now;
  _apInFlight = true;
  navigator.clipboard.readText().then(function(text){
    _apInFlight = false;
    if (!text) return;
    var code = extractOtp(text);
    if (!code) return;
    if (hashStr(text) === _lastHash) return;
    if (collectOtp().length === otpInputs.length) return;
    for (var i = 0; i < otpInputs.length; i++) otpInputs[i].value = code.charAt(i) || '';
    _lastHash = hashStr(text);
    if (code.length === otpInputs.length) submitOtp(code);
    else if (otpInputs[code.length]) try { otpInputs[code.length].focus({preventScroll:true}); } catch(e){}
  }).catch(function(){ _apInFlight = false; });
}

for (var ai = 0; ai < otpInputs.length; ai++) {
  (function(inp){
    inp.addEventListener('pointerdown', tryAutoPaste);
    inp.addEventListener('click', tryAutoPaste);
    inp.addEventListener('touchstart', tryAutoPaste, {passive: true});
  })(otpInputs[ai]);
}

var pendingPhone = '';
var pendingToken = '';
function submitOtp(code){
  var d = normalizePhone(phoneInput.value);
  var e164 = toE164(d);
  fetch(REST + '/verify-otp', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    body: JSON.stringify({ phone: e164, code: code })
  }).then(function(r){ return r.json().then(function(j){ return {status: r.status, body: j}; }); })
  .then(function(res){
    if (res.status === 200 && res.body.success) {
      if (res.body.data.is_new) {
        pendingPhone = e164;
        pendingToken = res.body.data.register_token;
        if (stepOtp) stepOtp.hidden = true;
        if (stepName) stepName.hidden = false;
        if (fullName) setTimeout(function(){ try { fullName.focus({preventScroll:true}); } catch(e){} }, 80);
        toast('شماره تأیید شد', 'success');
      } else {
        toast('ورود موفق!', 'success');
        setTimeout(postAuthRedirect, 900);
      }
    } else if (res.status === 429) {
      var retry = (res.body.error && res.body.error.retry_after) || 60;
      toast((res.body.error && res.body.error.message) || 'کمی صبر کنید', 'warning');
      startResend(retry);
      clearOtp();
    } else {
      clearOtp();
      toast((res.body.error && res.body.error.message) || 'کد نادرست است', 'error');
    }
  }).catch(function(){ toast('خطای شبکه', 'error'); });
}

function postAuthRedirect(){
  try {
    var rt = new URLSearchParams(window.location.search).get('redirect_to');
    if (rt) {
      var u = new URL(rt, window.location.origin);
      if (u.origin === window.location.origin) { window.location.href = u.toString(); return; }
    }
  } catch (e) {}
  window.location.reload();
}

function startResend(seconds){
  if (!resendBtn) return;
  var remain = parseInt(seconds, 10) || 60;
  resendBtn.disabled = true;
  resendBtn.innerHTML = 'ارسال مجدد تا<span style="display:inline-block;margin:0 5px;min-width:20px;text-align:center;">' + remain + '</span>ثانیه';
  var cd = resendBtn.querySelector('span');
  if (resendBtn.__timer) clearInterval(resendBtn.__timer);
  resendBtn.__timer = setInterval(function(){
    remain--;
    if (remain <= 0) {
      clearInterval(resendBtn.__timer);
      resendBtn.__timer = null;
      resendBtn.disabled = false;
      resendBtn.textContent = 'ارسال مجدد';
    } else if (cd) cd.textContent = String(remain);
  }, 1000);
}
function scheduleHint(){ if (!hintEl) return; hintEl.hidden = true; setTimeout(function(){ hintEl.hidden = false; }, 15000); }

if (fullName) fullName.addEventListener('input', function(){
  if (registerBtn) registerBtn.disabled = fullName.value.trim().length < 2;
});
if (registerBtn) registerBtn.addEventListener('click', function(e){
  e.preventDefault();
  if (registerBtn.disabled) return;
  var fn = fullName.value.trim();
  if (fn.length < 2) { toast('نام را وارد کنید', 'warning'); return; }
  var parts = fn.split(/\s+/).filter(function(x){ return x.length > 0; });
  var f = parts[0] || '';
  var l = parts.slice(1).join(' ');
  registerBtn.classList.add('zsg-loading');
  registerBtn.disabled = true;
  fetch(REST + '/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    body: JSON.stringify({ phone: pendingPhone, token: pendingToken, first_name: f, last_name: l })
  }).then(function(r){ return r.json().then(function(j){ return {status: r.status, body: j}; }); })
  .then(function(res){
    registerBtn.classList.remove('zsg-loading');
    if (res.status === 200 && res.body.success) {
      toast('ثبت نام موفق!', 'success');
      setTimeout(postAuthRedirect, 900);
    } else {
      registerBtn.disabled = false;
      toast((res.body.error && res.body.error.message) || 'خطا در ثبت نام', 'error');
    }
  }).catch(function(){
    registerBtn.classList.remove('zsg-loading');
    registerBtn.disabled = false;
    toast('خطای شبکه', 'error');
  });
});

for (var bi = 0; bi < openBtns.length; bi++) openBtns[bi].addEventListener('click', function(e){ e.preventDefault(); openModal(); });
if (closeBtn) closeBtn.addEventListener('click', closeModal);
if (overlay) overlay.addEventListener('click', function(e){ if (!FORCE_OPEN && e.target === overlay) closeModal(); });
document.addEventListener('keydown', function(e){ if (!FORCE_OPEN && e.key === 'Escape' && overlay && overlay.getAttribute('data-open') === '1') closeModal(); });
if (FORCE_OPEN) openModal();

updateContinue();
console.log('[ZSG Auth] v76 wired:', ROOT_ID);

})();
</script>
<?php endif; ?>
