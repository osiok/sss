<?php
declare(strict_types=1);
namespace ZSG\Auth\Frontend;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class PageTemplate {
    public static function register(): void {
        add_filter( 'template_include', [ __CLASS__, 'maybe_override' ], 9999 );
    }

    public static function maybe_override( $template ) {
        if ( ! is_singular() ) { return $template; }
        $post = get_queried_object();
        if ( ! $post instanceof \WP_Post ) { return $template; }

        $has_page_sc  = has_shortcode( (string) $post->post_content, 'zsg_auth_page' );
        $has_page_str = ( strpos( (string) $post->post_content, 'zsg_auth_page' ) !== false );

        if ( ! $has_page_sc && ! $has_page_str ) { return $template; }

        $custom = ZSG_AUTH_PATH . 'src/Frontend/Views/full-page-template.php';
        if ( is_readable( $custom ) ) {
            return $custom;
        }
        return $template;
    }
}
